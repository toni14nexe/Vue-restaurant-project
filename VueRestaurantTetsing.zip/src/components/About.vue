<template>
    <div>
        
        <section id="about"></section>
        <div class="row main">
            <div class="main-switch">
                <div class="col-12 title-div">
                    <h1 class="title">About</h1>
                </div>

                <div class="container-md">
                    <div class="row row-margin">
                        <div class="col-1 col-lg-1"></div>
                        <div class="col-10 col-lg-5 image-div">
                            <img src="../assets/images/about-img.jpg">
                        </div>
                        <div class="col-1 lg-off"></div>
                        <div class="col-1 lg-off"></div>
                        <div class="col-10 col-lg-5">
                            <p class="big-text">"You don't need a silver fork to eat good food."</p>
                            <p class="small-text align-right">Paul Prudhomme</p>
                        </div>
                        <div class="col-1 col-lg-1"></div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-1"></div>
                    <div class="col-10">
                        <br><br>
                        <p class="small-text">The best offer of traditional Chinese food and domestic drinks in a town with great culinary experience and long tradition...</p>
                    </div>
                    <div class="col-1"></div>
                </div>
            </div>
        </div>
    
    </div>
</template>

<script>
export default {

}
</script>
    
<style scoped>
    .title{
        margin-top: 2.5%;
        padding-top: 5%;
    }

    .title-div{
        padding-bottom: 5%;
    }

    @media screen and (min-width: 992px){
        .main-switch{
            height: 100%;
        }
    }
</style>