<template>
    <div>
        <center>
        <h1 class="title">404: Not found!</h1>
        <a href="./"><button class="sign-in-btn">Home</button></a>
        </center>
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>
    .title{
        font-size: 3rem;
        margin-top: 3%;
        margin-bottom: 3%;
    }
</style>